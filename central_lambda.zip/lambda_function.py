import json
import boto3
import time
import datetime
import uuid
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
AUDIT_TABLE_NAME = 'ruchiserv-audit-log'

def convert_floats(obj):
    """Recursively convert floats to Decimals for DynamoDB compatibility"""
    if isinstance(obj, float):
        return Decimal(str(obj))
    elif isinstance(obj, dict):
        return {k: convert_floats(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_floats(i) for i in obj]
    return obj

def get_timestamp():
    return datetime.datetime.utcnow().isoformat()

def write_audit_log(firm_id, table_name, action, entity_key, actor_id, before_snapshot, after_snapshot):
    """Writes an immutable record to the audit log table"""
    try:
        audit_table = dynamodb.Table(AUDIT_TABLE_NAME)
        log_entry = {
            'pk': f"AUDIT#{firm_id}",
            'sk': f"{int(time.time())}#{uuid.uuid4()}", # Time ordered unique ID
            'timestamp': get_timestamp(),
            'action': action, # CREATE, UPDATE, DELETE (SOFT)
            'target_table': table_name,
            'entity_key': json.dumps(entity_key),
            'actor_id': actor_id, 
            'before_snapshot': json.dumps(convert_floats(before_snapshot), default=str) if before_snapshot else None,
            'after_snapshot': json.dumps(convert_floats(after_snapshot), default=str) if after_snapshot else None
        }
        audit_table.put_item(Item=log_entry)
        print(f"✅ Audit Log Written: {action} on {table_name}")
    except Exception as e:
        print(f"❌ Audit Log Failed: {e}") 
        # meaningful error handling should happen here, but we don't want to crash the main transaction
        # per "Fail Open vs Fail Closed" debate - for now we log error and proceed.

    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"FATAL ERROR: {e}")
        return error(str(e))

def handle_whatsapp_webhook(data):
    """Processes Incoming WhatsApp Webhook Events (Button Clicks, etc.)"""
    print(f"📩 Webhook Incoming: {json.dumps(data)}")
    
    try:
        entry = data.get('entry', [])[0]
        changes = entry.get('changes', [])[0]
        value = changes.get('value', {})
        messages = value.get('messages', [])
        
        if messages:
            msg = messages[0]
            msg_id = msg.get('id')
            from_mobile = msg.get('from')
            
            # 1. Handle Button Reply (v37)
            if msg.get('type') == 'button':
                btn_payload = msg.get('button', {}).get('payload', '') # "ACTION|ORDER_ID|FIRM_ID"
                print(f"🔘 Button Payload: {btn_payload}")
                
                if '|' in btn_payload:
                    parts = btn_payload.split('|')
                    if len(parts) >= 3:
                        action = parts[0]
                        order_id = int(parts[1])
                        firm_id = parts[2]
                        
                        # Use Single Table Design 'ruchiserv_data'
                        table = dynamodb.Table('ruchiserv_data')
                        now = datetime.datetime.now().isoformat()
                        # SK format used by App CloudSyncService: 'orders#{id}'
                        key = {'pk': firm_id, 'sk': f'orders#{order_id}'}

                        if action == 'CONFIRM_ORDER':
                            print(f"✅ Confirming Order {order_id} for Firm {firm_id}")
                            try:
                                table.update_item(
                                    Key=key,
                                    UpdateExpression="SET clientStatus = :status, confirmedAt = :ts",
                                    ExpressionAttributeValues={':status': 'ACCEPTED', ':ts': now},
                                    ConditionExpression="attribute_exists(pk)" # Only update if exists
                                )
                            except Exception as e:
                                print(f"⚠️ Update failed (Order might not exist in Cloud): {e}")

                            # TODO: Notify Admin app via push or another mechanism (Rule C.4)
                            
                        elif action == 'REQUEST_CHANGES':
                            print(f"🟡 Change Requested for Order {order_id} for Firm {firm_id}")
                            try:
                                table.update_item(
                                    Key=key,
                                    UpdateExpression="SET clientStatus = :status, changeRequestedAt = :ts",
                                    ExpressionAttributeValues={':status': 'CHANGE_REQ', ':ts': now},
                                    ConditionExpression="attribute_exists(pk)"
                                )
                            except Exception as e:
                                print(f"⚠️ Update failed: {e}")
                            
                            # TODO: Notify Admin app
                
            # 2. Handle Text Reply
            elif msg.get('type') == 'text':
                text_body = msg.get('text', {}).get('body')
                print(f"💬 Text Received: {text_body}")
                
    except Exception as e:
        print(f"⚠️ Webhook Parse Error: {e}")
    
    # Always return 200 to acknowledge Receipt
    return success({'status': 'EVENT_RECEIVED'})

def lambda_handler(event, context):
    try:
        print(f"🔍 DEBUG: Event received: {json.dumps(event, default=str)}")
        
        raw_body = event.get('body')
        if raw_body:
            body = json.loads(raw_body)
            if body is None: body = {}
        else:
            body = {}
            
        # --- SNS DETECTION ---
        if 'Records' in event and len(event['Records']) > 0 and 'Sns' in event['Records'][0]:
            # Direct SNS Trigger
            sns_msg = event['Records'][0]['Sns']
            method = 'POST'
            table_name = 'messaging/ses/webhook'
            data = sns_msg
        elif body.get('Type') in ['Notification', 'SubscriptionConfirmation']:
            # SNS via API Gateway (HTTPS Subscription)
            method = 'POST'
            table_name = 'messaging/ses/webhook'
            data = body
        else:
            # Standard API call
            method = body.get('method', 'GET')
            table_name = body.get('table', 'firms')
            data = body.get('data', {})
            if data is None: data = {}

        # --- SPECIAL ROUTING FOR WHATSAPP WEBHOOKS ---
        # 1. GET Verification (Query Params)
        qs = event.get('queryStringParameters')
        if qs and qs.get('hub.mode') == 'subscribe':
            print("🔍 Detected WhatsApp Webhook Verification")
            mode = qs.get('hub.mode')
            token = qs.get('hub.verify_token')
            challenge = qs.get('hub.challenge')
            expected_token = 'ruchiserv_webhook_secure_123'
            print(f"🔍 DEBUG: Mode={mode}, Received Token='{token}', Expected Token='{expected_token}'")
            print(f"🔍 DEBUG: Challenge='{challenge}'")
            
            if mode == 'subscribe' and token == expected_token:
                print("✅ Webhook Verified!")
                return {
                    'statusCode': 200,
                    'headers': {'Content-Type': 'text/plain'},
                    'body': str(challenge)
                }
            print("❌ Webhook Token Mismatch!")
            return error('Verification failed')

        # 2. POST Event (Body contains object='whatsapp_business_account')
        elif isinstance(body, dict) and body.get('object') == 'whatsapp_business_account':
            print("🔍 Detected WhatsApp Webhook Event")
            # Proceed directly to webhook handling logic
            return handle_whatsapp_webhook(body)
        
        # --- STANDARD TABLE ROUTING ---
        filters = body.get('filters', {}) if isinstance(body, dict) else {}
        if filters is None: filters = {}
        
        # 1. Table Name Validation
        if table_name in ['ruchiserv_data', 'ruchiserv-audit-log']:
            full_table_name = table_name
        else:
            full_table_name = f'ruchiserv-{table_name}'
        
        table = dynamodb.Table(full_table_name)

        # 2. Extract Identity (Placeholder for Token Logic)
        # In a real JWT world, we extract this from 'Authorization' header.
        # For now, we trust the body but prepare the variable.
        # CRITICAL: Client must send 'firmId' in data for ownership checks in future.
        firm_id = data.get('firmId') or filters.get('firmId') or 'UNKNOWN_FIRM'
        actor_id = data.get('updatedBy') or 'API_USER'

        if method == 'GET':
            if 'sk_prefix' in filters:
                pk = filters.get('pk')
                sk_prefix = filters.get('sk_prefix')
                response = table.query(
                    KeyConditionExpression='pk = :pk AND begins_with(sk, :prefix)',
                    ExpressionAttributeValues={':pk': pk, ':prefix': sk_prefix}
                )
                items = response.get('Items', [])
                # Filter out soft-deleted items
                active_items = [i for i in items if not i.get('is_deleted', False)]
                return success(active_items)
            elif filters:
                response = table.get_item(Key=filters)
                item = response.get('Item')
                if item and item.get('is_deleted', False):
                    return success(None) # Treat as 404
                return success(item)
            else:
                # SCAN is dangerous, but keeping for compatibility. 
                # Should be removed in Phase 2.
                response = table.scan()
                items = response.get('Items', [])
                active_items = [i for i in items if not i.get('is_deleted', False)]
                return success(active_items)
        
        elif method == 'PUT':
            safe_data = convert_floats(data)
            
            # 3. Fetch Before Snapshot (Read before Write)
            # We need the keys to fetch. Assuming 'data' contains the full key.
            # Using get_item is safer than condition check for audit purposes.
            keys = {'pk': safe_data.get('pk'), 'sk': safe_data.get('sk')}
            before_snapshot = None
            if keys['pk'] and keys['sk']:
                try:
                    old_item_resp = table.get_item(Key=keys)
                    before_snapshot = old_item_resp.get('Item')
                except:
                    pass # It might be a new item

            # 4. Perform Write
            table.put_item(Item=safe_data)
            
            # 5. Async Audit Log
            action_type = 'UPDATE' if before_snapshot else 'CREATE'
            write_audit_log(firm_id, full_table_name, action_type, keys, actor_id, before_snapshot, safe_data)
            
            return success({'message': 'Created'})
        
        elif method == 'DELETE':
            # 6. SOFT DELETE IMPL
            # Replaces table.delete_item(Key=filters)
            
            # Fetch before snapshot
            keys = filters
            before_snapshot = None
            try:
                old_item_resp = table.get_item(Key=keys)
                before_snapshot = old_item_resp.get('Item')
            except:
                pass

            if not before_snapshot:
                 return error('Item not found or already deleted')

            # Perform Boolean Soft Delete
            table.update_item(
                Key=keys,
                UpdateExpression="SET is_deleted = :val, active = :activeVar",
                ExpressionAttributeValues={
                    ':val': True,
                    ':activeVar': False
                }
            )
            
            # Audit Log
            write_audit_log(firm_id, full_table_name, 'DELETE (SOFT)', keys, actor_id, before_snapshot, {'is_deleted': True})
            return success({'message': 'Deleted (Soft)'})
        
        # === OTP: POST /auth/otp/request ===
        elif method == 'POST' and table_name == 'auth/otp/request':
            from services.otp.manager import OtpManager
            mobile = data.get('mobile')
            if not mobile: return error('Mobile required')
            
            result = OtpManager().request_otp(mobile)
            if result['success']: return success(result)
            return error(result.get('error', 'Unknown error'))

        # === OTP: POST /auth/otp/verify ===
        elif method == 'POST' and table_name == 'auth/otp/verify':
            from services.otp.manager import OtpManager
            mobile = data.get('mobile')
            code = data.get('otp')
            if not mobile or not code: return error('Mobile and OTP required')
            
            result = OtpManager().verify_otp(mobile, code)
            if result['success']: return success(result)
            return error(result.get('error', 'Verification failed'))

        # === TRANSACTIONAL EMAIL: POST /messaging/transactional/send ===
        elif method == 'POST' and table_name == 'messaging/transactional/send':
            print(f"📧 Transactional Email Request: {data.get('type')}")
            from services.messaging import EmailService, EmailTemplates
            
            msg_type = data.get('type')  # ORDER or PO
            recipient = data.get('to')
            payload_data = data.get('data', {})
            
            if not recipient:
                return error('Recipient email (to) is required')
            
            svc = EmailService()
            
            if msg_type == 'ORDER':
                order = payload_data.get('order', {})
                dishes = payload_data.get('dishes', [])
                firm_id = payload_data.get('firmId', 'DEFAULT')
                # Fetch firm details for letterpad
                # First use order data which should have firm info from Flutter
                firm_details = {
                    'firmName': order.get('firmName', ''),
                    'name': order.get('firmName', ''),
                    'address': order.get('firmAddress', ''),
                    'mobile': order.get('firmMobile', order.get('firmPhone', '')),
                    'primaryMobile': order.get('firmMobile', ''),
                    'primaryEmail': order.get('firmEmail', ''),
                    'email': order.get('firmEmail', ''),
                    'gstNumber': order.get('firmGstin', ''),
                }
                # If order doesn't have firm name, try DB
                if not firm_details.get('firmName'):
                    try:
                        firm_table = dynamodb.Table('ruchiserv-firms')
                        resp = firm_table.get_item(Key={'pk': f'FIRM#{firm_id}', 'sk': 'PROFILE'})
                        if resp.get('Item'):
                            firm_details.update(resp['Item'])
                    except Exception as e:
                        print(f"⚠️ Could not fetch firm details: {e}")
                        firm_details['firmName'] = 'Your Caterer'
                        firm_details['name'] = 'Your Caterer'
                
                html_body = EmailTemplates.generate_order_html(order, dishes, firm_details)
                subject = f"Order Confirmed - {firm_details.get('firmName', firm_details.get('name', 'Your Caterer'))}"
                plain_body = f"Your order #{order.get('id')} has been confirmed. Total: ₹{order.get('grandTotal', 0)}"
                
                result = svc.send_email(recipient, subject, plain_body, html_body)
                if result:
                    return success({'success': True, 'message': 'Order confirmation email sent'})
                return error('Failed to send order email')
            
            elif msg_type == 'PO':
                po = payload_data.get('po', {})
                items = payload_data.get('items', [])
                firm_id = payload_data.get('firmId', 'DEFAULT')
                
                firm_details = {'name': 'RuchiServ Partner', 'address': ''}
                try:
                    firm_table = dynamodb.Table('ruchiserv-firms')
                    resp = firm_table.get_item(Key={'pk': f'FIRM#{firm_id}', 'sk': 'PROFILE'})
                    if resp.get('Item'):
                        firm_details = resp['Item']
                except Exception as e:
                    print(f"⚠️ Could not fetch firm details: {e}")
                
                html_body = EmailTemplates.generate_po_html(po, items, firm_details)
                subject = f"Purchase Order {po.get('poNumber')} - {firm_details.get('name', 'RuchiServ')}"
                plain_body = f"Purchase Order {po.get('poNumber')} has been created."
                
                result = svc.send_email(recipient, subject, plain_body, html_body)
                if result:
                    return success({'success': True, 'message': 'PO email sent'})
                return error('Failed to send PO email')
            
            else:
                return error(f"Unknown transactional type: {msg_type}")

        # === EMAIL: POST /messaging/email/send ===
        elif method == 'POST' and table_name == 'messaging/email/send':
            from services.messaging import EmailService
            recipient = data.get('to')
            subject = data.get('subject')
            body_content = data.get('body')
            if not recipient or not subject or not body_content:
                return error('to, subject, and body are required')
                
            result = EmailService().send_email(recipient, subject, body_content)
            if result['success']: return success(result)
            return error(result.get('error', 'Email failed'))

        # === WHATSAPP: POST /messaging/whatsapp/send ===
        elif method == 'POST' and table_name == 'messaging/whatsapp/send':
            print(f"🔍 DEBUG: Hitting 'send' route. Data: {data}") # ADDED DEBUG
            from services.messaging import WhatsAppService
            
            to_mobile = data.get('to')
            template = data.get('template')
            language = data.get('language', 'en_US')
            components = data.get('components', [])
            
            if not to_mobile or not template:
                return error('to and template are required')

            svc = WhatsAppService()
            success_status = svc.send_template(to_mobile, template, language, components)
            
            if success_status: 
                return success({'success': True})
            print("❌ DEBUG: send_template returned False") # ADDED DEBUG
            
            # RETURN DETAILED ERROR
            error_msg = getattr(svc, 'last_error', 'Unknown Error') or 'WhatsApp failed (Check logs)'
            return error(f"WhatsApp Failed: {error_msg}")

        # === WHATSAPP: POST /messaging/whatsapp/send_order_pdf ===
        elif method == 'POST' and table_name == 'messaging/whatsapp/send_order_pdf':
            print(f"🔍 DEBUG: Hitting 'send_order_pdf' route. Data Keys: {list(data.keys())}")
            from services.messaging import WhatsAppService
            import base64
            
            to_mobile = data.get('to')
            pdf_base64 = data.get('pdf_base64')
            text_params = data.get('text_params', [])
            
            # Match Flutter parameter order: [Name, ID, Date, Time, Pax, Total, ...]
            customer_name = text_params[0] if len(text_params) > 0 else 'Customer'
            order_id = text_params[1] if len(text_params) > 1 else 'Order'
            
            if not to_mobile or not pdf_base64:
                return error('to and pdf_base64 are required')

            # 1. Upload PDF to S3
            s3_bucket = 'ruchiserv-invoices'
            # Sanitize order_id for filename (no spaces)
            safe_order_id = str(order_id).replace(" ", "_")
            s3_key = f"invoices/order_{safe_order_id}_{int(time.time())}.pdf"
            s3_url = None
            
            try:
                print("1️⃣ Uploading PDF to S3...")
                s3_client = boto3.client('s3', region_name='ap-south-1')
                pdf_bytes = base64.b64decode(pdf_base64)
                s3_client.put_object(
                    Bucket=s3_bucket,
                    Key=s3_key,
                    Body=pdf_bytes,
                    ContentType='application/pdf'
                )
                s3_url = f"https://{s3_bucket}.s3.ap-south-1.amazonaws.com/{s3_key}"
                print(f"✅ PDF uploaded: {s3_url}")
            except Exception as e:
                print(f"❌ S3 Upload failed: {e}")
                return error(f"S3 Upload failed: {str(e)}")

            # 2. Upload to Meta (Get Media ID)
            print("2️⃣ Uploading PDF to Meta to get Media ID...")
            svc = WhatsAppService()  # INIT SERVICE
            media_filename = f"RuchiServ_Order_{safe_order_id}.pdf"
            media_id = svc.upload_media(pdf_bytes, filename=media_filename)
            print(f"✅ Meta Media ID: {media_id}")
            
            if not media_id:
                return error(f"Failed to upload PDF to Meta: {svc.last_error}")

            filename = media_filename
            
            # 3. Send WhatsApp Template
            print("3️⃣ Sending WhatsApp with Document Header...")
            
            # Extract params from incoming data (sent by Flutter client)
            wa_text_params = data.get('text_params', [])
            raw_order_id = data.get('order_id_raw', 'Unknown')
            firm_id = data.get('firm_id', 'Unknown')

            # Interactive Buttons (v37)
            # Payload format: ACTION|ORDER_ID|FIRM_ID
            button_payloads = [
                f"CONFIRM_ORDER|{raw_order_id}|{firm_id}",
                f"REQUEST_CHANGES|{raw_order_id}|{firm_id}"
            ]

            success_status = svc.send_document_template(
                to_mobile,
                'ruchiserv_order_interactive',
                media_id,
                filename,
                'en',  # Changed from 'en_US' to match Meta template
                wa_text_params,
                buttons=button_payloads
            )
            
            if success_status:
                # Update sentAt timestamp in DB
                try:
                    # Use Single Table Design
                    table = boto3.resource('dynamodb').Table('ruchiserv_data')
                    key = {'pk': firm_id, 'sk': f'orders#{raw_order_id}'}
                    
                    table.update_item(
                        Key=key,
                        UpdateExpression="SET sentAt = :val",
                        ExpressionAttributeValues={':val': datetime.datetime.now().isoformat()},
                        ConditionExpression="attribute_exists(pk)"
                    )
                except Exception as e:
                    print(f"⚠️ Failed to update sentAt: {e}")

                return success({'success': True, 'pdf_url': s3_url})
            
            error_msg = getattr(svc, 'last_error', 'Unknown Error')
            # Still return success if PDF uploaded but WhatsApp failed (Meta pending)
            return success({'success': True, 'pdf_url': s3_url, 'whatsapp_warning': error_msg})
            
        # Webhook GET/POST logic is handled at the top of lambda_handler

        # === WHATSAPP WEBHOOK POST HANDLED AT TOP ===

        # === SES: POST /messaging/ses/webhook (Bounce/Complaint Handling) ===
        elif method == 'POST' and table_name == 'messaging/ses/webhook':
            print(f"📧 SES Webhook Incoming: {json.dumps(data)}")
            
            # 1. Handle SNS Subscription Confirmation
            if data.get('Type') == 'SubscriptionConfirmation':
                subscribe_url = data.get('SubscribeURL')
                print(f"🔗 SNS Subscription Confirmation: {subscribe_url}")
                # Automatically visit the URL to confirm (optional but helpful)
                import urllib.request
                try:
                    with urllib.request.urlopen(subscribe_url) as resp:
                        print(f"✅ Subscription Confirmed: {resp.status}")
                except Exception as e:
                    print(f"⚠️ Failed to confirm subscription: {e}")
                return success({'status': 'SUBSCRIPTION_CONFIRMED'})

            # 2. Handle SES Notifications
            try:
                msg_body = data.get('Message')
                if not msg_body:
                    # Might be direct SES notification if not via SNS (unlikely for HTTPS but safe)
                    ses_notif = data
                else:
                    ses_notif = json.loads(msg_body)
                
                notif_type = ses_notif.get('notificationType')
                print(f"📢 SES Notification Type: {notif_type}")
                
                blacklist_table = dynamodb.Table('ruchiserv-email-blacklist')
                
                if notif_type == 'Bounce':
                    bounce = ses_notif.get('bounce', {})
                    bounced_recipients = bounce.get('bouncedRecipients', [])
                    for recipient in bounced_recipients:
                        email = recipient.get('emailAddress')
                        reason = bounce.get('bounceType', 'Unknown')
                        print(f"🚫 Blacklisting Bounced Email: {email} ({reason})")
                        blacklist_table.put_item(Item={
                            'email': email,
                            'type': 'BOUNCE',
                            'timestamp': get_timestamp(),
                            'reason': reason,
                            'messageId': ses_notif.get('mail', {}).get('messageId')
                        })
                
                elif notif_type == 'Complaint':
                    complaint = ses_notif.get('complaint', {})
                    complained_recipients = complaint.get('complainedRecipients', [])
                    for recipient in complained_recipients:
                        email = recipient.get('emailAddress')
                        reason = complaint.get('complaintFeedbackType', 'Unknown')
                        print(f"🚫 Blacklisting Complained Email: {email} ({reason})")
                        blacklist_table.put_item(Item={
                            'email': email,
                            'type': 'COMPLAINT',
                            'timestamp': get_timestamp(),
                            'reason': reason,
                            'messageId': ses_notif.get('mail', {}).get('messageId')
                        })
                
                return success({'status': 'PROCESSED'})
            except Exception as e:
                print(f"⚠️ SES Webhook Error: {e}")
                return error(f"Failed to process SES notification: {str(e)}")

        else:
            return error('Unknown method')
            
    except Exception as e:
        print(f"FATAL ERROR: {e}")
        return error(str(e))

def success(data):
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
        'body': json.dumps(data, default=str)
    }

def error(msg):
    return {
        'statusCode': 400,
        'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'error': msg})
    }
