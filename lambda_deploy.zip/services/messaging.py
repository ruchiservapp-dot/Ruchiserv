import boto3
import os
from botocore.exceptions import ClientError

class EmailService:
    def __init__(self):
        # Initialize SES client
        self.client = boto3.client('ses', region_name='ap-south-1')
        self.from_email = os.environ.get('SES_FROM_EMAIL', 'noreply@ruchiserv.com')

    def send_email(self, recipient: str, subject: str, body: str, html_body: str = None) -> bool:
        """
        Sends an email via AWS SES.
        Args:
            recipient: To email address
            subject: Email subject
            body: Plain text body
            html_body: Optional HTML body
        """
        try:
            if not self.from_email:
                print("Error: SES_FROM_EMAIL environment variable not set")
                return False

            message = {
                'Subject': {'Data': subject, 'Charset': 'UTF-8'},
                'Body': {
                    'Text': {'Data': body, 'Charset': 'UTF-8'}
                }
            }
            
            if html_body:
                message['Body']['Html'] = {'Data': html_body, 'Charset': 'UTF-8'}

            response = self.client.send_email(
                Source=self.from_email,
                Destination={'ToAddresses': [recipient]},
                Message=message
            )
            print(f"📧 Email sent to {recipient}! Message ID: {response['MessageId']}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to send email: {str(e)}")
            return False

# ... (Existing EmailService) ...
import json
import urllib.request
import urllib.error

class WhatsAppService:
    def __init__(self):
        self.phone_id = os.environ.get('WA_PHONE_NUMBER_ID')
        self.token = os.environ.get('WA_ACCESS_TOKEN')
        self.api_version = 'v19.0'
        self.last_error = None
        
    def upload_media(self, file_bytes: bytes, mime_type: str = 'application/pdf', filename: str = 'order.pdf') -> str:
        """
        Uploads media to Meta and returns the Media ID.
        """
        if not self.phone_id or not self.token:
            self.last_error = "Missing Credentials (WA_PHONE_NUMBER_ID or WA_ACCESS_TOKEN)"
            return None

        url = f"https://graph.facebook.com/{self.api_version}/{self.phone_id}/media"
        
        # Meta requires multipart/form-data. Using basic urllib is complex for multipart.
        # Ideally we use 'requests' lib, but if not available in Lambda layer, we might need a workaround.
        # Assuming 'requests' IS available (standard in many layers) or we rely on 'requests_toolbelt'.
        # For simplicity in this raw script without layers, we'll try a basic construction or assume requests.
        # Fallback: We will strictly use the standard library 'urllib' with manual multipart construction.
        
        boundary = 'wL36Yn8afVp8Ag7AmP8qZ0SA4n1v9T'
        
        # Build Body
        body = []
        # messaging_product="whatsapp"
        body.append(f'--{boundary}')
        body.append('Content-Disposition: form-data; name="messaging_product"')
        body.append('')
        body.append('whatsapp')
        
        # file
        body.append(f'--{boundary}')
        body.append(f'Content-Disposition: form-data; name="file"; filename="{filename}"')
        body.append(f'Content-Type: {mime_type}')
        body.append('')
        # (We append bytes later)
        
        # End
        footer = f'\r\n--{boundary}--\r\n'
        
        # Combine
        header_bytes = '\r\n'.join(body).encode('utf-8') + b'\r\n'
        final_body = header_bytes + file_bytes + footer.encode('utf-8')
        
        try:
            req = urllib.request.Request(url, data=final_body, method='POST')
            req.add_header('Authorization', f'Bearer {self.token}')
            req.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
            
            with urllib.request.urlopen(req) as response:
                resp_data = json.loads(response.read().decode())
                return resp_data.get('id')
        except Exception as e:
            print(f"❌ Media Upload Failed: {e}")
            self.last_error = f"Media Upload Failed: {e}"
            return None

    def send_document_template(self, to_mobile: str, template_name: str, media_id: str, filename: str, language_code: str = 'en_US', body_text_params: list = None) -> bool:
        """
        Sends a Document Template (Header=PDF).
        """
        components = [
            {
                "type": "header",
                "parameters": [
                    {
                        "type": "document",
                        "document": {
                            "id": media_id,
                            "filename": filename
                        }
                    }
                ]
            }
        ]
        
        if body_text_params:
            components.append({
                "type": "body",
                "parameters": [{"type": "text", "text": p} for p in body_text_params]
            })
            
        return self.send_template(to_mobile, template_name, language_code, components)

    def send_template(self, to_mobile: str, template_name: str, language_code: str = 'en_US', components: list = None) -> bool:
        """
        Sends a WhatsApp Template message via Meta Graph API.
        """
        if not self.phone_id or not self.token:
            print("❌ WhatsApp Error: Credentials not found in Env Vars.")
            self.last_error = "Credentials not found in Env Vars"
            return False

        url = f"https://graph.facebook.com/{self.api_version}/{self.phone_id}/messages"
        
        # Clean mobile number
        to_mobile = to_mobile.replace('+', '').replace(' ', '').replace('-', '')
        
        # Construct payload
        payload = {
            "messaging_product": "whatsapp",
            "to": to_mobile,
            "type": "template",
            "template": {
                "name": template_name,
                "language": {"code": language_code}
            }
        }
        
        if components:
            payload["template"]["components"] = components

        try:
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(url, data=data, method='POST')
            req.add_header('Authorization', f'Bearer {self.token}')
            req.add_header('Content-Type', 'application/json')
            
            with urllib.request.urlopen(req) as response:
                resp_data = json.loads(response.read().decode())
                print(f"💬 WhatsApp sent to {to_mobile}: ID {resp_data['messages'][0]['id']}")
                return True
                
        except urllib.error.HTTPError as e:
            err_body = e.read().decode()
            print(f"❌ WhatsApp Failed ({e.code}): {err_body}")
            self.last_error = f"WhatsApp HTTP {e.code}: {err_body}"
            return False
        except Exception as e:
            print(f"❌ WhatsApp Exception: {str(e)}")
            self.last_error = f"Exception: {str(e)}"
            return False

class EmailTemplates:
    @staticmethod
    def _get_header(firm_details: dict) -> str:
        """Generates the standard Letter Pad header."""
        name = firm_details.get('name', 'RuchiServ Partner')
        address = firm_details.get('address', '').replace('\n', '<br>')
        
        return f"""
        <div style="border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px;">
            <h1 style="color: #2c3e50; margin: 0; font-size: 28px;">{name}</h1>
            <p style="color: #7f8c8d; margin: 10px 0 0 0; font-size: 14px; line-height: 1.5;">{address}</p>
        </div>
        """

    @staticmethod
    def _get_styles() -> str:
        return """
        <style>
            body { font-family: 'Helvetica', 'Arial', sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th { background-color: #f8f9fa; border-bottom: 2px solid #ddd; padding: 12px; text-align: left; font-weight: bold; }
            td { border-bottom: 1px solid #eee; padding: 12px; }
            .total-row td { border-top: 2px solid #333; font-weight: bold; font-size: 16px; }
            .footer { margin-top: 40px; font-size: 12px; color: #aaa; text-align: center; border-top: 1px solid #eee; padding-top: 20px; }
            .badge { background: #e1f5fe; color: #0277bd; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        </style>
        """

    @staticmethod
    def generate_order_html(order: dict, dishes: list, firm_details: dict) -> str:
        header = EmailTemplates._get_header(firm_details)
        styles = EmailTemplates._get_styles()
        
        # Format Rows
        rows_html = ""
        for i, d in enumerate(dishes, 1):
            name = d.get('dishName', 'Item')
            qty = d.get('pax', 0)
            rate = d.get('pricePerPlate', 0)
            amount = qty * rate
            rows_html += f"<tr><td>{i}</td><td>{name}</td><td>{qty}</td><td>₹{rate}</td><td>₹{amount}</td></tr>"

        return f"""
        <!DOCTYPE html>
        <html>
        <head>{styles}</head>
        <body>
            {header}
            
            <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                <div>
                    <strong>Customer Details:</strong><br>
                    {order.get('customerName')}<br>
                    {order.get('mobile', '')}<br>
                    {order.get('location', '')}
                </div>
                <div style="text-align: right;">
                    <strong>Order Confirmation</strong><br>
                    Order ID: #{order.get('id')}<br>
                    Date: {order.get('date')}<br>
                    <span class="badge">{order.get('mealType')} ({order.get('foodType')})</span>
                </div>
            </div>

            <table>
                <thead><tr><th>#</th><th>Item</th><th>Qty (Pax)</th><th>Rate</th><th>Amount</th></tr></thead>
                <tbody>{rows_html}</tbody>
                <tr class="total-row">
                    <td colspan="4" style="text-align: right;">Total Amount:</td>
                    <td>₹{order.get('grandTotal', 0)}</td>
                </tr>
            </table>

            <p style="font-size: 14px; color: #666;">
                <strong>Notes:</strong> {order.get('notes', 'None')}
            </p>
            
            <div class="footer">
                Thank you for your business!<br>
                Generated by RuchiServ
            </div>
        </body>
        </html>
        """

    @staticmethod
    def generate_po_html(po: dict, items: list, firm_details: dict) -> str:
        header = EmailTemplates._get_header(firm_details)
        styles = EmailTemplates._get_styles()
        
        rows_html = ""
        for i, item in enumerate(items, 1):
            name = item.get('itemName', 'Item')
            qty = item.get('quantity', 0)
            unit = item.get('unit', 'units')
            rows_html += f"<tr><td>{i}</td><td>{name}</td><td>{qty} {unit}</td></tr>"

        return f"""
        <!DOCTYPE html>
        <html>
        <head>{styles}</head>
        <body>
            {header}
            
            <h2 style="color: #2c3e50;">PURCHASE ORDER: {po.get('poNumber')}</h2>
            
            <div style="margin-bottom: 20px;">
                <strong>To Vendor:</strong><br>
                {po.get('vendorName')}<br>
                Date: {po.get('date', 'N/A')}
            </div>

            <p>Please supply the following items:</p>

            <table>
                <thead><tr><th>#</th><th>Item</th><th>Quantity</th></tr></thead>
                <tbody>{rows_html}</tbody>
            </table>
            
            <div class="footer">
                Please confirm receipt of this order.<br>
            </div>
        </body>
        </html>
        """
